import heroImage from "../../assets/images/official-welcome-group.jpg";

const GalleryHero = () => {
  return (
    <section
      className="relative h-[420px] bg-cover bg-center"
      style={{ backgroundImage: `url(${heroImage})` }}
    >

      <div className="absolute inset-0 bg-slate-900/70"></div>

      <div className="relative z-10 flex h-full items-center justify-center">

        <div className="text-center">

          <h1 className="text-6xl font-bold text-white">
            Gallery
          </h1>

          <p className="mt-4 text-lg text-gray-200">
            Capturing Our Journey, Success and Memories
          </p>

        </div>

      </div>
    </section>
  );
};

export default GalleryHero;