type Props = {
  image: string;
  title: string;
};

const GalleryCard = ({ image, title }: Props) => {
  return (
    <div className="group overflow-hidden rounded-2xl shadow-lg bg-white">
      <img
        src={image}
        alt={title}
        className="h-80 w-full object-cover transition duration-500 group-hover:scale-110"
      />

      <div className="p-5">
        <h3 className="text-lg font-semibold text-gray-800">
          {title}
        </h3>
      </div>
    </div>
  );
};

export default GalleryCard;