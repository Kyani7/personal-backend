import GalleryCard from "./GalleryCard";
import { galleryImages } from "./GalleryData";

const GalleryGrid = () => {
  return (
    <section className="bg-gray-50 py-20">
      <div className="mx-auto max-w-7xl px-6">

        <div className="mb-12 text-center">
          <h2 className="text-4xl font-bold text-slate-900">
            Our Gallery
          </h2>

          <p className="mt-4 text-gray-600">
            Explore memorable moments from Hima Aus events,
            counselling sessions and student success stories.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {galleryImages.map((item) => (
            <GalleryCard
              key={item.id}
              image={item.image}
              title={item.title}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default GalleryGrid;