import { FaArrowRight } from "react-icons/fa";

import heroImage from "../../assets/images/contact-banner.jpg";

const ContactHero = () => {
  return (
    <section className="relative overflow-hidden">
      {/* Background */}
      <img
        src={heroImage}
        alt="Students"
        className="absolute inset-0 h-full w-full object-cover"
      />

      {/* Overlay */}
      <div className="absolute inset-0 bg-slate-900/75"></div>

      {/* Decorative Blur */}
      <div className="absolute left-10 top-10 h-64 w-64 rounded-full bg-blue-500/20 blur-3xl"></div>
      <div className="absolute right-10 bottom-10 h-64 w-64 rounded-full bg-cyan-500/20 blur-3xl"></div>

      <div className="relative z-10 mx-auto flex min-h-[650px] max-w-7xl items-center px-6">
        <div className="max-w-3xl">

          {/* Breadcrumb */}
          <p className="text-blue-300 font-medium tracking-wide">
            Home / Contact Us
          </p>

          <h1
           
            className="mt-6 text-6xl font-extrabold leading-tight text-white"
          >
            Let's Build Your
            <span className="block text-blue-400">
              Dream Career Abroad
            </span>
          </h1>

          < p
           
            className="mt-8 max-w-2xl text-lg leading-8 text-gray-300"
          >
            Whether you're planning to study in Australia, Canada,
            the UK, or the USA, our expert education counsellors
            will guide you through every step of your journey.
          </p>

          <div className="mt-10 flex flex-wrap gap-5">

            <button className="flex items-center gap-3 rounded-xl bg-blue-600 px-8 py-4 font-semibold text-white transition hover:bg-blue-700">
              Get Started
              <FaArrowRight />
            </button>

            <button className="rounded-xl border border-white px-8 py-4 font-semibold text-white transition hover:bg-white hover:text-slate-900">
              Book Consultation
            </button>

          </div>

        </div>
      </div>
    </section>
  );
};

export default ContactHero;