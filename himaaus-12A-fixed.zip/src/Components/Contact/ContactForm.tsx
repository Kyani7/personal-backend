import { useState } from "react";
import {
  FaMapMarkerAlt,
  FaPhoneAlt,
  FaEnvelope,
  FaClock,
  FaCheckCircle,
} from "react-icons/fa";

type FormData = {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
};

const initialForm: FormData = {
  name: "",
  email: "",
  phone: "",
  subject: "",
  message: "",
};

const ContactForm = () => {
  const [form, setForm] = useState<FormData>(initialForm);
  const [errors, setErrors] = useState<Partial<FormData>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const validate = (): boolean => {
    const newErrors: Partial<FormData> = {};

    if (!form.name.trim()) newErrors.name = "Full name is required";

    if (!form.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = "Enter a valid email address";
    }

    if (!form.phone.trim()) {
      newErrors.phone = "Phone number is required";
    } else if (!/^[0-9+\-\s()]{7,15}$/.test(form.phone)) {
      newErrors.phone = "Enter a valid phone number";
    }

    if (!form.message.trim()) newErrors.message = "Please write a message";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validate()) return;

    setSubmitting(true);

    // TODO: wire this up to the real backend/email API once it's available.
    await new Promise((resolve) => setTimeout(resolve, 800));

    setSubmitting(false);
    setSubmitted(true);
    setForm(initialForm);
  };

  return (
    <section className="bg-gray-50 py-24">
      <div className="mx-auto grid max-w-7xl gap-10 px-6 lg:grid-cols-2">

        {/* Form */}
        <div className="rounded-3xl bg-white p-10 shadow-xl">
          <h2 className="mb-2 text-4xl font-bold text-slate-900">
            Send us a Message
          </h2>

          <p className="mb-8 text-gray-500">
            We'd love to hear from you. Fill out the form below.
          </p>

          {submitted ? (
            <div className="flex flex-col items-center justify-center rounded-2xl bg-green-50 px-6 py-16 text-center">
              <FaCheckCircle className="mb-4 text-5xl text-green-500" />
              <h3 className="text-2xl font-bold text-slate-900">
                Message Sent!
              </h3>
              <p className="mt-2 max-w-sm text-gray-500">
                Thanks for reaching out. Our team will get back to you within
                24 hours.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="mt-6 rounded-xl bg-blue-600 px-6 py-3 font-semibold text-white transition hover:bg-blue-700"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form className="space-y-6" onSubmit={handleSubmit} noValidate>

              <div>
                <input
                  type="text"
                  name="name"
                  placeholder="Full Name"
                  value={form.name}
                  onChange={handleChange}
                  className={`w-full rounded-xl border px-5 py-4 outline-none transition focus:border-blue-600 ${
                    errors.name ? "border-red-400" : "border-gray-300"
                  }`}
                />
                {errors.name && (
                  <p className="mt-1 text-sm text-red-500">{errors.name}</p>
                )}
              </div>

              <div>
                <input
                  type="email"
                  name="email"
                  placeholder="Email Address"
                  value={form.email}
                  onChange={handleChange}
                  className={`w-full rounded-xl border px-5 py-4 outline-none transition focus:border-blue-600 ${
                    errors.email ? "border-red-400" : "border-gray-300"
                  }`}
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-500">{errors.email}</p>
                )}
              </div>

              <div>
                <input
                  type="text"
                  name="phone"
                  placeholder="Phone Number"
                  value={form.phone}
                  onChange={handleChange}
                  className={`w-full rounded-xl border px-5 py-4 outline-none transition focus:border-blue-600 ${
                    errors.phone ? "border-red-400" : "border-gray-300"
                  }`}
                />
                {errors.phone && (
                  <p className="mt-1 text-sm text-red-500">{errors.phone}</p>
                )}
              </div>

              <input
                type="text"
                name="subject"
                placeholder="Subject"
                value={form.subject}
                onChange={handleChange}
                className="w-full rounded-xl border border-gray-300 px-5 py-4 outline-none transition focus:border-blue-600"
              />

              <div>
                <textarea
                  name="message"
                  rows={5}
                  placeholder="Write your message..."
                  value={form.message}
                  onChange={handleChange}
                  className={`w-full rounded-xl border px-5 py-4 outline-none transition focus:border-blue-600 ${
                    errors.message ? "border-red-400" : "border-gray-300"
                  }`}
                />
                {errors.message && (
                  <p className="mt-1 text-sm text-red-500">
                    {errors.message}
                  </p>
                )}
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full rounded-xl bg-blue-600 py-4 text-lg font-semibold text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {submitting ? "Sending..." : "Send Message"}
              </button>

            </form>
          )}
        </div>

        {/* Contact Information */}
        <div className="rounded-3xl bg-slate-900 p-10 text-white shadow-xl">

          <h2 className="mb-8 text-4xl font-bold">
            Contact Information
          </h2>

          <div className="space-y-8">

            <div className="flex gap-5">
              <FaMapMarkerAlt className="mt-1 text-2xl text-blue-400" />
              <div>
                <h4 className="font-semibold">Office</h4>
                <p className="text-gray-300">
                  Kathmandu, Nepal
                </p>
              </div>
            </div>

            <div className="flex gap-5">
              <FaPhoneAlt className="mt-1 text-2xl text-blue-400" />
              <div>
                <h4 className="font-semibold">Phone</h4>
                <p className="text-gray-300">
                  +977 980-502-7022
                </p>
              </div>
            </div>

            <div className="flex gap-5">
              <FaEnvelope className="mt-1 text-2xl text-blue-400" />
              <div>
                <h4 className="font-semibold">Email</h4>
                <p className="text-gray-300">
                  info@himaaus.com
                </p>
              </div>
            </div>

            <div className="flex gap-5">
              <FaClock className="mt-1 text-2xl text-blue-400" />
              <div>
                <h4 className="font-semibold">Working Hours</h4>
                <p className="text-gray-300">
                  Sun – Fri | 9:00 AM – 6:00 PM
                </p>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};

export default ContactForm;
