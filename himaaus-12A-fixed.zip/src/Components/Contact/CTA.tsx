import { FaArrowRight, FaPhoneAlt } from "react-icons/fa";

const CTA = () => {
  return (
    <section className="relative overflow-hidden bg-slate-900 py-20">
      {/* Decorative blur */}
      <div className="absolute left-1/4 top-0 h-72 w-72 -translate-y-1/2 rounded-full bg-blue-500/20 blur-3xl"></div>
      <div className="absolute right-1/4 bottom-0 h-72 w-72 translate-y-1/2 rounded-full bg-cyan-500/20 blur-3xl"></div>

      <div className="relative z-10 mx-auto max-w-4xl px-6 text-center">
        <h2 className="text-4xl font-bold text-white sm:text-5xl">
          Ready to Start Your Journey?
        </h2>

        <p className="mt-6 text-lg text-gray-300">
          Book a free consultation with our expert counsellors and take the
          first step toward studying abroad.
        </p>

        <div className="mt-10 flex flex-wrap justify-center gap-5">
          <a
            href="#contact-form"
            className="flex items-center gap-3 rounded-xl bg-blue-600 px-8 py-4 font-semibold text-white transition hover:bg-blue-700"
          >
            Book Free Consultation
            <FaArrowRight />
          </a>

          <a
            href="tel:+9779805027022"
            className="flex items-center gap-3 rounded-xl border border-white px-8 py-4 font-semibold text-white transition hover:bg-white hover:text-slate-900"
          >
            <FaPhoneAlt />
            Call Us Now
          </a>
        </div>
      </div>
    </section>
  );
};

export default CTA;
