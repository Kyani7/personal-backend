const GoogleMap = () => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">

        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-slate-900">
            Find Our Office
          </h2>

          <p className="mt-4 text-gray-500">
            Visit us for expert counselling and personalized guidance.
          </p>
        </div>

        <div className="overflow-hidden rounded-3xl shadow-2xl border border-gray-200">
          <iframe
            title="Hima Aus Location"
            src="https://www.google.com/maps?q=Kathmandu,Nepal&output=embed"
            width="100%"
            height="500"
            loading="lazy"
            className="border-0"
          ></iframe>
        </div>

      </div>
    </section>
  );
};

export default GoogleMap;