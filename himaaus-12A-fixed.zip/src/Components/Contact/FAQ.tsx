import { useState } from "react";
import { FaChevronDown } from "react-icons/fa";

const faqs = [
  {
    question: "Which countries do you provide counselling for?",
    answer:
      "We provide expert counselling for Australia, Canada, the UK, the USA, New Zealand, and other popular study destinations.",
  },
  {
    question: "Do you help with visa applications?",
    answer:
      "Yes. Our experienced team assists with document preparation, visa applications, and interview guidance.",
  },
  {
    question: "Can you help me find scholarships?",
    answer:
      "Absolutely! We help students identify scholarship opportunities and prepare competitive applications.",
  },
  {
    question: "Is the consultation free?",
    answer:
      "Yes. Your first consultation is completely free and includes course and university guidance.",
  },
];

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="bg-slate-50 py-20">
      <div className="mx-auto max-w-4xl px-6">
        <div className="mb-12 text-center">
          <p className="font-semibold uppercase tracking-widest text-blue-600">
            Frequently Asked Questions
          </p>
          <h2 className="mt-3 text-4xl font-bold text-slate-900">
            Have Questions?
          </h2>
          <p className="mt-4 text-gray-600">
            Find answers to some of the most common questions from students.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="overflow-hidden rounded-2xl bg-white shadow-md"
            >
              <button
                onClick={() =>
                  setOpenIndex(openIndex === index ? null : index)
                }
                className="flex w-full items-center justify-between p-6 text-left"
              >
                <span className="text-lg font-semibold text-slate-800">
                  {faq.question}
                </span>

                <FaChevronDown
                  className={`transition-transform duration-300 ${
                    openIndex === index ? "rotate-180" : ""
                  }`}
                />
              </button>

              <div
                className={`transition-all duration-300 ${
                  openIndex === index
                    ? "max-h-40 px-6 pb-6"
                    : "max-h-0 overflow-hidden"
                }`}
              >
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;