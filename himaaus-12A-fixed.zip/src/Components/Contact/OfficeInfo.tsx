import { FaMapMarkerAlt, FaPhoneAlt, FaEnvelope } from "react-icons/fa";

const offices = [
  {
    city: "Kathmandu, Nepal",
    // TODO: confirm exact street address before launch. Public directories
    // disagree (Min Bhawan / New Baneshwor / Putalisadak) and several may be
    // outdated or refer to different Nepal branches (Hima Aus also has
    // branches in Pokhara, Dhading, Itahari, and Chitwan).
    address: "Address to be confirmed",
    phone: "+977 980-502-7022",
    email: "info@himaaus.com",
  },
  {
    city: "Sydney, Australia",
    address: "Suite 1106, Level 11, 370 Pitt Street, Sydney NSW 2000",
    phone: "+61 2 9269 0551",
    email: "info@himaaus.com",
  },
  {
    city: "Colombo, Sri Lanka",
    address: "227-2/1, Galle Road, Bambalapitiya, Colombo 00400",
    phone: "+94 11 259 3026",
    email: "srilanka@himaaus.com",
  },
];

const OfficeInfo = () => {
  return (
    <section className="bg-white py-20">
      <div className="mx-auto max-w-7xl px-6">

        <div className="mb-12 text-center">
          <p className="font-semibold uppercase tracking-widest text-blue-600">
            Our Branches
          </p>
          <h2 className="mt-3 text-4xl font-bold text-slate-900">
            Visit an Office Near You
          </h2>
          <p className="mt-4 text-gray-500">
            With offices across Nepal, Australia, and Sri Lanka, expert
            guidance is never far away.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-3">
          {offices.map((office) => (
            <div
              key={office.city}
              className="rounded-3xl border border-gray-100 bg-gray-50 p-8 shadow-sm transition hover:-translate-y-2 hover:shadow-xl"
            >
              <h3 className="mb-4 text-xl font-bold text-slate-800">
                {office.city}
              </h3>

              <div className="space-y-3 text-gray-600">
                <div className="flex items-start gap-3">
                  <FaMapMarkerAlt className="mt-1 text-blue-600" />
                  <span>{office.address}</span>
                </div>
                <div className="flex items-start gap-3">
                  <FaPhoneAlt className="mt-1 text-blue-600" />
                  <span>{office.phone}</span>
                </div>
                <div className="flex items-start gap-3">
                  <FaEnvelope className="mt-1 text-blue-600" />
                  <span>{office.email}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

export default OfficeInfo;
