import {
  FaMapMarkerAlt,
  FaPhoneAlt,
  FaEnvelope,
  FaClock,
} from "react-icons/fa";

const cards = [
  {
    icon: <FaMapMarkerAlt />,
    title: "Visit Us",
    info: "Kathmandu, Nepal", // TODO: confirm exact street address — sources conflict, see note in OfficeInfo.tsx
    color: "from-blue-500 to-cyan-500",
  },
  {
    icon: <FaPhoneAlt />,
    title: "Call Us",
    info: "+977 980-502-7022",
    color: "from-green-500 to-emerald-500",
  },
  {
    icon: <FaEnvelope />,
    title: "Email Us",
    info: "info@himaaus.com",
    color: "from-orange-500 to-red-500",
  },
  {
    icon: <FaClock />,
    title: "Office Hours",
    info: "Sun - Fri | 9 AM - 6 PM",
    color: "from-purple-500 to-pink-500",
  },
];

const ContactCards = () => {
  return (
    <section className="relative z-20 -mt-24 px-6">
      <div className="mx-auto grid max-w-7xl gap-8 md:grid-cols-2 lg:grid-cols-4">
        {cards.map((card, index) => (
          <div
            key={index}
            className="group rounded-3xl bg-white p-8 shadow-xl transition-all duration-500 hover:-translate-y-4 hover:shadow-2xl"
          >
            <div
              className={`mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-r ${card.color} text-2xl text-white transition duration-500 group-hover:rotate-6 group-hover:scale-110`}
            >
              {card.icon}
            </div>

            <h3 className="mb-3 text-xl font-bold text-slate-800">
              {card.title}
            </h3>

            <p className="leading-7 text-gray-500">{card.info}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ContactCards;