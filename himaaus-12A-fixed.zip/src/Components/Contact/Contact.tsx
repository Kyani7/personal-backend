import ContactHero from "./ContactHero";
import ContactCard from "./ContactCards";
import ContactForm from "./ContactForm";
import OfficeInfo from "./OfficeInfo";
import GoogleMap from "./GoogleMap";
import FAQ from "./FAQ";
import CTA from "./CTA";

const Contact = () => {
  return (
    <>
      <ContactHero />
      <ContactCard />
      <div id="contact-form">
        <ContactForm />
      </div>
      <OfficeInfo />
      <GoogleMap />
      <FAQ />
      <CTA />
    </>
  );
};

export default Contact;