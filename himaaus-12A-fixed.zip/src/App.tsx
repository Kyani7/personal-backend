import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Contact from "./Components/Contact/Contact";
import Gallery from "./Components/Gallery/Gallery";

function App() {
  return (
    <BrowserRouter>
      {/*
        Temporary nav for previewing the Contact & Gallery pages in isolation.
        Replace with the shared site header/nav once merged with the rest of the app.
      */}
      <nav className="flex gap-6 border-b border-gray-200 bg-white px-6 py-4">
        <Link to="/contact" className="font-semibold text-slate-700 hover:text-blue-600">
          Contact Us
        </Link>
        <Link to="/gallery" className="font-semibold text-slate-700 hover:text-blue-600">
          Gallery
        </Link>
      </nav>

      <Routes>
        <Route path="/" element={<Contact />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/gallery" element={<Gallery />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;